# Dataset

ShieldOps was developed using a publicly available cybersecurity threat-detection dataset containing 10,000 network-flow records across 13 features.

The project materials describe the dataset as publicly available through Kaggle.

## Local setup

Place the dataset file here:

```text
data/cybersecurity.csv
```

The analysis code expects the file to contain the fields used by the project, including:

- `attack_type`
- `timestamp`
- `user_agent`
- `bytes_sent`
- `bytes_received`
- `dst_port`
- `protocol`

## Repository policy

The dataset is intentionally not committed to this repository.

Before redistributing the dataset, verify its original license and terms of use.

Do not commit sensitive, private or proprietary network data.
