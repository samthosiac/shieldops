# Results

This directory contains generated figures and other model-analysis outputs.

Recommended figures for the portfolio version:

- Confusion matrix
- ROC curve
- Random Forest feature importance
- Malicious traffic rate by hour
- Top ports by malicious rate
- Bytes-sent distribution
- Top user agents in malicious traffic

Generated files should be reproducible from the source code rather than manually edited.
