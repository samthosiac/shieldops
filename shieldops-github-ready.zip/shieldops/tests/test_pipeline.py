import pandas as pd

from shieldops.model import build_model, evaluate_model, train_model
from shieldops.preprocessing import FEATURES, clean_data


def sample_data(n: int = 100) -> pd.DataFrame:
    rows = []
    for i in range(n):
        rows.append(
            {
                "attack_type": "benign" if i % 2 == 0 else "port_scan",
                "timestamp": f"2026-01-01 {i % 24:02d}:00:00",
                "user_agent": "Mozilla/5.0" if i % 3 else "zgrab",
                "bytes_sent": 100 + i,
                "bytes_received": 200 + i,
                "dst_port": 443 if i % 2 == 0 else 22,
                "protocol": "TCP" if i % 3 else "UDP",
            }
        )
    return pd.DataFrame(rows)


def test_clean_data_creates_expected_features():
    data = clean_data(sample_data())
    assert all(feature in data.columns for feature in FEATURES)
    assert "attack_binary" in data.columns
    assert set(data["attack_binary"].unique()) <= {0, 1}


def test_model_training_and_evaluation():
    data = clean_data(sample_data())
    X = data[FEATURES]
    y = data["attack_binary"]

    model, _, X_test, _, y_test = train_model(X, y)

    assert isinstance(model, type(build_model()))
    evaluation = evaluate_model(model, X_test, y_test)

    assert 0.0 <= evaluation.accuracy <= 1.0
    assert 0.0 <= evaluation.precision <= 1.0
    assert 0.0 <= evaluation.recall <= 1.0
    assert 0.0 <= evaluation.roc_auc <= 1.0
    assert len(evaluation.confusion_matrix) == 2
