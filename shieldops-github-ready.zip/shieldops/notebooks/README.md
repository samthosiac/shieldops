# Notebooks

The original ShieldOps work was developed through multiple Colab deliverables.

The portfolio repository uses the cleaned Python modules in `src/shieldops/` as the primary implementation. Original coursework notebooks can be added here later if you want to preserve the development history.

Recommended naming:

```text
01_data_check.ipynb
02_exploratory_analysis.ipynb
03_random_forest_model.ipynb
04_final_analysis.ipynb
```
