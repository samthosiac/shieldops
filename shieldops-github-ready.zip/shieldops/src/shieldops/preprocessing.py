"""Data preparation utilities for ShieldOps."""

from __future__ import annotations

import pandas as pd

FEATURES = [
    "bytes_sent",
    "bytes_received",
    "dst_port",
    "protocol",
    "hour",
    "ua_length",
]

PROTOCOL_MAP = {
    "TCP": 1,
    "UDP": 2,
    "ICMP": 3,
    "IGMP": 4,
    "GRE": 5,
    "ESP": 6,
}


def load_data(path: str) -> pd.DataFrame:
    """Load the cybersecurity dataset from CSV."""
    return pd.read_csv(path)


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Apply the cleaning and feature-engineering steps used by ShieldOps."""
    data = df.copy()

    data = data.drop_duplicates()

    data["user_agent_clean"] = (
        data["user_agent"].astype(str).str.lower().str.strip()
    )

    # Preserve the original project's forward-fill approach.
    data = data.ffill()

    data["timestamp"] = pd.to_datetime(data["timestamp"], errors="coerce")
    data["hour"] = data["timestamp"].dt.hour

    data["ua_length"] = data["user_agent"].astype(str).str.len()

    data["attack_binary"] = (
        data["attack_type"].astype(str).str.lower().eq("benign").astype(int)
    )
    data["attack_binary"] = 1 - data["attack_binary"]

    data["protocol"] = data["protocol"].astype(str).str.upper()
    data["protocol"] = (
        data["protocol"].map(PROTOCOL_MAP).fillna(0).astype(int)
    )

    return data


def make_features(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Return model features X and binary target y."""
    data = clean_data(df)
    X = data[FEATURES].copy()
    y = data["attack_binary"].copy()
    return X, y
