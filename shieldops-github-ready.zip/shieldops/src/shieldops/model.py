"""Model training and evaluation utilities for ShieldOps."""

from __future__ import annotations

from dataclasses import dataclass

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split


@dataclass
class Evaluation:
    """Container for binary-classification evaluation results."""

    accuracy: float
    precision: float
    recall: float
    roc_auc: float
    confusion_matrix: list[list[int]]


def build_model() -> RandomForestClassifier:
    """Create the Random Forest configuration used in the final project."""
    return RandomForestClassifier(
        n_estimators=200,
        max_depth=None,
        class_weight="balanced",
        random_state=32,
    )


def train_model(X, y):
    """Train ShieldOps using a stratified 70/30 train-test split."""
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.30,
        random_state=32,
        stratify=y,
    )

    model = build_model()
    model.fit(X_train, y_train)

    return model, X_train, X_test, y_train, y_test


def evaluate_model(model, X_test, y_test) -> Evaluation:
    """Evaluate a trained binary classifier."""
    predictions = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]

    return Evaluation(
        accuracy=accuracy_score(y_test, predictions),
        precision=precision_score(y_test, predictions, zero_division=0),
        recall=recall_score(y_test, predictions, zero_division=0),
        roc_auc=roc_auc_score(y_test, probabilities),
        confusion_matrix=confusion_matrix(y_test, predictions).tolist(),
    )
