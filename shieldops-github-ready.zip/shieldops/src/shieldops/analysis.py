"""Run the ShieldOps analysis pipeline."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.metrics import ConfusionMatrixDisplay, RocCurveDisplay, roc_curve, auc

from .model import train_model, evaluate_model
from .preprocessing import FEATURES, clean_data, load_data


ROOT = Path(__file__).resolve().parents[2]
DATA_PATH = ROOT / "data" / "cybersecurity.csv"
RESULTS_DIR = ROOT / "results" / "figures"


def save_exploratory_figures(df: pd.DataFrame) -> None:
    """Save the major exploratory-analysis figures."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(12, 5))
    port_rates = (
        df.groupby("dst_port")["attack_binary"]
        .mean()
        .sort_values(ascending=False)
        .head(20)
    )
    port_rates.plot(kind="bar")
    plt.title("Top Ports by Malicious Rate")
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "top_ports_malicious_rate.png", dpi=200)
    plt.close()

    plt.figure(figsize=(8, 5))
    sns.countplot(data=df, x="protocol", hue="attack_type")
    plt.title("Protocol Usage by Attack Label")
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "protocol_usage_by_attack.png", dpi=200)
    plt.close()

    plt.figure(figsize=(12, 5))
    hourly = df.groupby("hour")["attack_binary"].mean()
    hourly.plot(kind="line", marker="*")
    plt.title("Malicious Traffic Rate by Hour")
    plt.xlabel("Hour of Day")
    plt.ylabel("Malicious Rate")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "malicious_rate_by_hour.png", dpi=200)
    plt.close()

    plt.figure(figsize=(10, 6))
    ua_counts = (
        df[df["attack_binary"] == 1]["user_agent_clean"]
        .value_counts()
        .head(10)
    )
    ua_counts.plot(kind="barh")
    plt.title("Top 10 User-Agents in Malicious Traffic")
    plt.xlabel("Count")
    plt.ylabel("User-Agent")
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "top_malicious_user_agents.png", dpi=200)
    plt.close()


def save_model_figures(model, X_test, y_test) -> None:
    """Save the confusion matrix, ROC curve and feature importance plots."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    predictions = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]

    ConfusionMatrixDisplay.from_predictions(y_test, predictions)
    plt.title("ShieldOps Confusion Matrix")
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "confusion_matrix.png", dpi=200)
    plt.close()

    fpr, tpr, _ = roc_curve(y_test, probabilities)
    roc_auc = auc(fpr, tpr)

    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.3f}")
    plt.plot([0, 1], [0, 1], linestyle="--")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ShieldOps ROC Curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "roc_curve.png", dpi=200)
    plt.close()

    importances = pd.Series(
        model.feature_importances_,
        index=FEATURES,
    ).sort_values(ascending=False)

    plt.figure(figsize=(8, 5))
    sns.barplot(x=importances.values, y=importances.index)
    plt.title("Random Forest Feature Importance")
    plt.xlabel("Importance Score")
    plt.ylabel("Feature")
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "feature_importance.png", dpi=200)
    plt.close()


def main() -> None:
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found at {DATA_PATH}. "
            "See data/README.md for setup instructions."
        )

    raw = load_data(str(DATA_PATH))
    data = clean_data(raw)

    print(f"Dataset shape: {raw.shape}")
    print("\nClass distribution:")
    print(data["attack_binary"].value_counts())

    save_exploratory_figures(data)

    X = data[FEATURES]
    y = data["attack_binary"]

    model, X_train, X_test, y_train, y_test = train_model(X, y)
    evaluation = evaluate_model(model, X_test, y_test)

    save_model_figures(model, X_test, y_test)

    print("\nEvaluation")
    print(f"Accuracy:  {evaluation.accuracy:.4f}")
    print(f"Precision: {evaluation.precision:.4f}")
    print(f"Recall:    {evaluation.recall:.4f}")
    print(f"ROC AUC:   {evaluation.roc_auc:.4f}")
    print("Confusion matrix:")
    print(evaluation.confusion_matrix)


if __name__ == "__main__":
    main()
